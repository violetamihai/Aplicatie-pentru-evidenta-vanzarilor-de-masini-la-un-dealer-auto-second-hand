using Firma_vanzari_auto.Pages.Clienti;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Collections.Generic;

namespace Firma_vanzari_auto.Pages.Masini
{
    public class Masina_Cautare_AvansataModel : PageModel
    {
        public List<MasinaInfo> listMasini = new List<MasinaInfo>();
        public String Criteriu = "";
        public String Ordine = "";



        public void OnPost()
        {
            Criteriu = Request.Form["Criteriu"];
            Ordine = Request.Form["Ordine"];

            if (Criteriu.Contains("Kilometraj") && Ordine.Contains("Crescator"))
            {

                try
                {
                    String connectionString = "Data Source=DESKTOP-MI4FVE6\\SQLEXPRESS;Initial Catalog=ProiectMihaiVioleta;Integrated Security=True;Encrypt=False";

                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        connection.Open();
                        String sql = "select Masina.Model, masina.SerieSasiu, Kilometraj, PutereMaxima_CP,Pret, Masina.MasinaID from masina, dosar where Dosar.MasinaID=masina.MasinaID order by Kilometraj";
                        using (SqlCommand command = new SqlCommand(sql, connection))
                        {

                            using (SqlDataReader reader = command.ExecuteReader())
                            {
                                while (reader.Read())
                                {
                                    MasinaInfo masinaInfo = new MasinaInfo();
                                    masinaInfo.Model = reader.GetString(0);
                                    masinaInfo.SerieSasiu = reader.GetString(1);
                                    masinaInfo.Kilometraj = "" + reader.GetInt32(2);
                                    masinaInfo.PutereMaxima_CP = reader.GetString(3);
                                    masinaInfo.Pret = "" + reader.GetInt32(4);
                                    masinaInfo.MasinaID = "" + reader.GetInt32(5);
                                    listMasini.Add(masinaInfo);
                                }

                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    throw;

                }
            }

            else if (Criteriu.Contains("Pret") && Ordine.Contains("Crescator"))
            {
                try
                {
                    String connectionString = "Data Source=DESKTOP-MI4FVE6\\SQLEXPRESS;Initial Catalog=ProiectMihaiVioleta;Integrated Security=True;Encrypt=False";

                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        connection.Open();
                        String sql = "select Masina.Model, masina.SerieSasiu, Kilometraj, PutereMaxima_CP,Pret, Masina.MasinaID from masina, dosar where Dosar.MasinaID=masina.MasinaID order by Pret";
                        using (SqlCommand command = new SqlCommand(sql, connection))
                        {

                            using (SqlDataReader reader = command.ExecuteReader())
                            {
                                while (reader.Read())
                                {
                                    MasinaInfo masinaInfo = new MasinaInfo();
                                    masinaInfo.Model = reader.GetString(0);
                                    masinaInfo.SerieSasiu = reader.GetString(1);
                                    masinaInfo.Kilometraj = "" + reader.GetInt32(2);
                                    masinaInfo.PutereMaxima_CP = reader.GetString(3);
                                    masinaInfo.Pret = "" + reader.GetInt32(4);
                                    masinaInfo.MasinaID = "" + reader.GetInt32(5);
                                    listMasini.Add(masinaInfo);
                                }

                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    throw;

                }
            }

            else if (Criteriu.Contains("PutereMaxima_CP") && Ordine.Contains("Crescator"))
            {
                try
                {
                    String connectionString = "Data Source=DESKTOP-MI4FVE6\\SQLEXPRESS;Initial Catalog=ProiectMihaiVioleta;Integrated Security=True;Encrypt=False";

                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        connection.Open();
                        String sql = "select Masina.Model, masina.SerieSasiu, Kilometraj, PutereMaxima_CP,Pret, Masina.MasinaID from masina, dosar where Dosar.MasinaID=masina.MasinaID order by PutereMaxima_CP";
                        using (SqlCommand command = new SqlCommand(sql, connection))
                        {

                            using (SqlDataReader reader = command.ExecuteReader())
                            {
                                while (reader.Read())
                                {
                                    MasinaInfo masinaInfo = new MasinaInfo();
                                    masinaInfo.Model = reader.GetString(0);
                                    masinaInfo.SerieSasiu = reader.GetString(1);
                                    masinaInfo.Kilometraj = "" + reader.GetInt32(2);
                                    masinaInfo.PutereMaxima_CP = reader.GetString(3);
                                    masinaInfo.Pret = "" + reader.GetInt32(4);
                                    masinaInfo.MasinaID = "" + reader.GetInt32(5);
                                    listMasini.Add(masinaInfo);
                                }

                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    throw;

                }
            }


            else if (Criteriu.Contains("Kilometraj") && Ordine.Contains("Descrescator"))
            {

                try
                {
                    String connectionString = "Data Source=DESKTOP-MI4FVE6\\SQLEXPRESS;Initial Catalog=ProiectMihaiVioleta;Integrated Security=True;Encrypt=False";

                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        connection.Open();
                        String sql = "select Masina.Model, masina.SerieSasiu, Kilometraj, PutereMaxima_CP,Pret, Masina.MasinaID from masina, dosar where Dosar.MasinaID=masina.MasinaID order by Kilometraj DESC";
                        using (SqlCommand command = new SqlCommand(sql, connection))
                        {

                            using (SqlDataReader reader = command.ExecuteReader())
                            {
                                while (reader.Read())
                                {
                                    MasinaInfo masinaInfo = new MasinaInfo();
                                    masinaInfo.Model = reader.GetString(0);
                                    masinaInfo.SerieSasiu = reader.GetString(1);
                                    masinaInfo.Kilometraj = "" + reader.GetInt32(2);
                                    masinaInfo.PutereMaxima_CP = reader.GetString(3);
                                    masinaInfo.Pret = "" + reader.GetInt32(4);
                                    masinaInfo.MasinaID = "" + reader.GetInt32(5);
                                    listMasini.Add(masinaInfo);
                                }

                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    throw;

                }
            }

            else if (Criteriu.Contains("Pret") && Ordine.Contains("Descrescator"))
            {
                try
                {
                    String connectionString = "Data Source=DESKTOP-MI4FVE6\\SQLEXPRESS;Initial Catalog=ProiectMihaiVioleta;Integrated Security=True;Encrypt=False";

                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        connection.Open();
                        String sql = "select Masina.Model, masina.SerieSasiu, Kilometraj, PutereMaxima_CP,Pret, Masina.Masina.ID from masina, dosar where Dosar.MasinaID=masina.MasinaID order by Pret DESC";
                        using (SqlCommand command = new SqlCommand(sql, connection))
                        {

                            using (SqlDataReader reader = command.ExecuteReader())
                            {
                                while (reader.Read())
                                {
                                    MasinaInfo masinaInfo = new MasinaInfo();
                                    masinaInfo.Model = reader.GetString(0);
                                    masinaInfo.SerieSasiu = reader.GetString(1);
                                    masinaInfo.Kilometraj = "" + reader.GetInt32(2);
                                    masinaInfo.PutereMaxima_CP = reader.GetString(3);
                                    masinaInfo.Pret = "" + reader.GetInt32(4);
                                    masinaInfo.MasinaID = "" + reader.GetInt32(5);
                                    listMasini.Add(masinaInfo);
                                }

                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    throw;

                }
            }

            else if (Criteriu.Contains("PutereMaxima_CP") && Ordine.Contains("Descrescator"))
            {
                try
                {
                    String connectionString = "Data Source=DESKTOP-MI4FVE6\\SQLEXPRESS;Initial Catalog=ProiectMihaiVioleta;Integrated Security=True;Encrypt=False";

                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        connection.Open();
                        String sql = "select Masina.Model, masina.SerieSasiu, Kilometraj, PutereMaxima_CP,Pret, Masina.MasinaID from masina, dosar where Dosar.MasinaID=masina.MasinaID order by PutereMaxima_CP DESC";
                        using (SqlCommand command = new SqlCommand(sql, connection))
                        {

                            using (SqlDataReader reader = command.ExecuteReader())
                            {
                                while (reader.Read())
                                {
                                    MasinaInfo masinaInfo = new MasinaInfo();
                                    masinaInfo.Model = reader.GetString(0);
                                    masinaInfo.SerieSasiu = reader.GetString(1);
                                    masinaInfo.Kilometraj = "" + reader.GetInt32(2);
                                    masinaInfo.PutereMaxima_CP = reader.GetString(3);
                                    masinaInfo.Pret = "" + reader.GetInt32(4);
                                    masinaInfo.MasinaID= "" + reader.GetInt32(5);

                                    listMasini.Add(masinaInfo);
                                }

                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    throw;

                }
            }



        }
       

		

	}



}





