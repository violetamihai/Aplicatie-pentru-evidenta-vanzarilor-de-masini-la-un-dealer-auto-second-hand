using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System;
using System.Data.SqlClient;

namespace Firma_vanzari_auto.Pages.Masini
{
    public class IndexModel : PageModel
    {
        public List<MasinaInfo> listMasini = new List<MasinaInfo>();
        public void OnGet()
        {
            try
            {
                String connectionString = "Data Source=DESKTOP-MI4FVE6\\SQLEXPRESS;Initial Catalog=ProiectMihaiVioleta;Integrated Security=True;Encrypt=False";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    String sql = "SELECT MasinaID, SerieSasiu, Model, An, Pret,Descriere FROM Masina";
                    using (SqlCommand command = new SqlCommand(sql, connection))
                    {
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                MasinaInfo masinaInfo = new MasinaInfo();
								masinaInfo.MasinaID = "" + reader.GetInt32(0);
								//masinaInfo.ReprezentantaID = "" + reader.GetInt32(1);
								
								//masinaInfo.DealerID = "" + reader.GetInt32(3);
								masinaInfo.SerieSasiu = reader.GetString(1);
								masinaInfo.Model = "" + reader.GetString(2);
                                masinaInfo.An = reader.GetString(3);
                                masinaInfo.Pret = "" + reader.GetInt32(4);
                                masinaInfo.Descriere = reader.GetString(5);
                                listMasini.Add(masinaInfo);
                            }

                        }
                    }
                }
            }
            catch (Exception)
            {/*
               Console.WriteLine("Exception: " + ex.ToString());
*/
                throw;
            }

        }
    }

    public class MasinaInfo
    {
        public String MasinaID;
		public String ReprezentantaID;
		public String ComandaID;
		public String DealerID;
		public String SerieSasiu;
		public String Model;
        public String An;
        public String Pret;
        public String Descriere;

		public String NrFisaInmatriculare;
        public String NrCarteIdentitateMasina;
        public String NrCertificatAutentificare;
        public String NrCarnetService;
		public String Transmisie;
		public String Kilometraj;
		public String Combustibil;
        public String Capacitate_L;
        public String ModelMotor;
        public String PutereMaxima_CP;
        public String CapacitatePortbagaj_L;
        public String Jante;
        public String SistemClimatizare;
        public String NrLocuri;
        public String Suspensii;
        public String TipVolan;
        public String ComputerBord;
        public String SistemFranare;
       
         
		



    }


}
