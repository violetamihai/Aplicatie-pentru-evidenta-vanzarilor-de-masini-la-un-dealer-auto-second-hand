using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System;
using System.Data.SqlClient;
using System.Numerics;

namespace Firma_vanzari_auto.Pages.Masini
{
    public class Masina_DetaliiModel : PageModel
    {
        public MasinaInfo masinaInfo = new MasinaInfo();
        //public ComandaInfo comandaInfo = new ComandaInfo();
        public String errorMessage = "";
        public String successMessage = "";
        public String InformatieMasina = "" + "<br>";
        public void OnGet()
        {
            String id = Request.Query["id"];
            

            try
            {
                String connectionString = "Data Source=DESKTOP-MI4FVE6\\SQLEXPRESS;Initial Catalog=ProiectMihaiVioleta;Integrated Security=True;Encrypt=False";
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    String sql = "SELECT SerieSasiu, Model, An, Pret, Descriere, NrFisaInmatriculare, NrCarteIdentitateMasina, NrCertificatAutentificare, NrCarnetService, Transmisie, Kilometraj, Combustibil, Capacitate_L, ModelMotor, PutereMaxima_CP, CapacitatePortbagaj_L, Jante, SistemClimatizare, NrLocuri, Suspensii, TipVolan, ComputerBord, SistemFranare FROM Masina, Dosar WHERE Masina.MasinaID=@id and Dosar.MasinaID=@id  ";

                    using (SqlCommand command = new SqlCommand(sql, connection))
                    {
                        command.Parameters.AddWithValue("@id", id);
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                masinaInfo.SerieSasiu = reader.GetString(0);
								masinaInfo.Model = reader.GetString(1);
								masinaInfo.An = reader.GetString(2);
								masinaInfo.Pret = "" + reader.GetInt32(3);
								masinaInfo.Descriere = reader.GetString(4);
								masinaInfo.NrFisaInmatriculare = reader.GetString(5);
								masinaInfo.NrCarteIdentitateMasina = reader.GetString(6);
								masinaInfo.NrCertificatAutentificare = reader.GetString(7);
								masinaInfo.NrCarnetService = reader.GetString(8);
								masinaInfo.Transmisie = reader.GetString(9);
								masinaInfo.Kilometraj = "" + reader.GetInt32(10);
								masinaInfo.Combustibil = reader.GetString(11);
								masinaInfo.Capacitate_L = reader.GetString(12);
								masinaInfo.ModelMotor = reader.GetString(13);
								masinaInfo.PutereMaxima_CP = reader.GetString(14);
								masinaInfo.CapacitatePortbagaj_L = reader.GetString(15);
								masinaInfo.Jante = reader.GetString(16);
								masinaInfo.SistemClimatizare = reader.GetString(17);
								masinaInfo.NrLocuri = reader.GetString(18);
								masinaInfo.Suspensii = reader.GetString(19);
								masinaInfo.TipVolan = reader.GetString(20);
								masinaInfo.ComputerBord = reader.GetString(21);
								masinaInfo.SistemFranare = reader.GetString(22);


                            }
                        }

                    }
                }
            }
            catch (Exception ex)
            {
                errorMessage = ex.Message + "primul";
            }

      

        }
    }
}







