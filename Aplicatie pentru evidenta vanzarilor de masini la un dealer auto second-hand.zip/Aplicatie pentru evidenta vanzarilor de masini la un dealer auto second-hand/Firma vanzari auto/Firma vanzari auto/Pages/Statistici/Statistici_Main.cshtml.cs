using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Firma_vanzari_auto.Pages.Clienti;
using System.Data;
using System.Runtime.InteropServices;
using System.Data;
using System.Security.Cryptography.Xml;


namespace Firma_vanzari_auto.Pages.Statistici
{
    public class Statistici_MainModel : PageModel
    {
        public List<ChartInfo> listCharts = new List<ChartInfo>();
        public List<RepInfo> listRep = new List<RepInfo>();
        public List<gf3Info> listgf3 = new List<gf3Info>();
        public List<gf4Info> listgf4 = new List<gf4Info>();
        
       


        public string ChartJson { get; internal set; }
        public void OnGet()
        {
            try
            {
                String connectionString = "Data Source=DESKTOP-MI4FVE6\\SQLEXPRESS;Initial Catalog=ProiectMihaiVioleta;Integrated Security=True;Encrypt=False";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    String sql = "select  Dealer.Nume ,Sum(Comanda.Valoare) from Dealer, ComandaDealer, Comanda where Dealer.DealerId=ComandaDealer.DealerID and comanda.ComandaId=ComandaDealer.ComandaID and  YEAR(Data) = 2023 group by Dealer.Nume  order by Sum(Valoare) ASC";
                    using (SqlCommand command = new SqlCommand(sql, connection))
                    {
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                ChartInfo chartInfo = new ChartInfo();
                                chartInfo.Nume = reader.GetString(0);
                                chartInfo.Vanzari = "" + reader.GetInt32(1);
								listCharts.Add(chartInfo);
							}

                        }
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }


            try
            {
                String connectionString = "Data Source=DESKTOP-MI4FVE6\\SQLEXPRESS;Initial Catalog=ProiectMihaiVioleta;Integrated Security=True;Encrypt=False";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    String sql = "select  Reprezentanta.Oras ,Sum(Comanda.Valoare) from Reprezentanta,Dealer, ComandaDealer, Comanda where Reprezentanta.ReprezentantaID=Dealer.ReprezentantaID and   Dealer.DealerId=ComandaDealer.DealerID and comanda.ComandaId=ComandaDealer.ComandaID and  YEAR(Data) = 2023 group by Reprezentanta.Oras  order by Sum(Valoare) ASC";
                    using (SqlCommand command = new SqlCommand(sql, connection))
                    {
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                RepInfo repInfo = new RepInfo();
                                repInfo.Nume = reader.GetString(0);
                                repInfo.Vanzari = "" + reader.GetInt32(1);
                                listRep.Add(repInfo);
                            }

                        }
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }

            try
            {
                String connectionString = "Data Source=DESKTOP-MI4FVE6\\SQLEXPRESS;Initial Catalog=ProiectMihaiVioleta;Integrated Security=True;Encrypt=False";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    String sql = "SELECT  nume, SUM(Comanda.Valoare) FROM Client, Comanda WHERE Client.ClientID=comanda.ClientID group by Nume, prenume Having Avg(Comanda.Valoare)>=(SELECT avg(c2.Valoare) from Comanda c2)";
                    using (SqlCommand command = new SqlCommand(sql, connection))
                    {
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                gf3Info Gf3Info = new gf3Info();
                                Gf3Info.Nume = reader.GetString(0);
                                Gf3Info.Vanzari = "" + reader.GetInt32(1); ;
                                listgf3.Add(Gf3Info);
                            }

                        }
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }

            try
            {
                String connectionString = "Data Source=DESKTOP-MI4FVE6\\SQLEXPRESS;Initial Catalog=ProiectMihaiVioleta;Integrated Security=True;Encrypt=False";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    String sql = "SELECT\r\n    DayOfMonth,\r\n    SUM(Subquery.Valoare) AS TotalValoare\r\nFROM (\r\n    SELECT\r\n        DATEPART(DAY, Comanda.Data) AS DayOfMonth,\r\n        Comanda.Valoare\r\n    FROM\r\n        Comanda\r\n    WHERE\r\n        MONTH(Comanda.Data) = MONTH(GETDATE())\r\n        AND YEAR(Comanda.Data) = YEAR(GETDATE())\r\n) AS Subquery\r\nGROUP BY\r\n    DayOfMonth\r\nORDER BY\r\n    DayOfMonth;";
                    using (SqlCommand command = new SqlCommand(sql, connection))
                    {
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                gf4Info Gf4Info = new gf4Info();
                                Gf4Info.Zi = "" + reader.GetInt32(0);
                                Gf4Info.Comenzi = "" + reader.GetInt32(1); ;
                                listgf4.Add(Gf4Info);
                            }

                        }
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }

           





        }

       
        }
    }


    public class ChartInfo
    {
        public String Nume;
        public String Vanzari;
        

    }

    public class RepInfo
    {
        public String Nume;
        public String Vanzari;


    }

    public class gf3Info
    {
        public String Nume;
        public String Vanzari;


    }

    public class gf4Info
    {
        public String Zi;
        public String Comenzi;


    }

   






