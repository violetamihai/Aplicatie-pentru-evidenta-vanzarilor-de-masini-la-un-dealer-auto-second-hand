using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Data.SqlClient;

namespace Firma_vanzari_auto.Pages.Statistici
{
    public class Cate_ComenziModel : PageModel
    {
        public List<gf5Info> listgf5 = new List<gf5Info>();
        public String An, Luna, Zi;
        

        public void OnPost()
        {

            An = Request.Form["An"];
            Luna = Request.Form["Luna"];
            Zi = Request.Form["Zi"];

            try
            {
                String connectionString = "Data Source=DESKTOP-MI4FVE6\\SQLEXPRESS;Initial Catalog=ProiectMihaiVioleta;Integrated Security=True;Encrypt=False";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    String sql = "SELECT   COUNT(ComandaID) AS CommandsCount FROM (    SELECT         DATEPART(DAY, Comanda.Data) AS DayOfMonth,        Comanda.ComandaID     FROM        Comanda    WHERE       MONTH(Comanda.Data) = @TargetMonth         AND YEAR(Comanda.Data) = @TargetYear        AND DAY(Comanda.Data) = @TargetDay ) AS Subquery GROUP BY    DayOfMonth ORDER BY     DayOfMonth;";
                    using (SqlCommand command = new SqlCommand(sql, connection))
                    {
                        command.Parameters.AddWithValue("@TargetMonth", Luna);
                        command.Parameters.AddWithValue("@TargetYear", An);
                        command.Parameters.AddWithValue("@TargetDay", Zi);
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                gf5Info Gf5Info = new gf5Info();
                                Gf5Info.Numar = "" + reader.GetInt32(0);

                                listgf5.Add(Gf5Info);
                            }

                        }
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }
        }

        

    }
    public class gf5Info
    {
        public String Numar;



    }
}
