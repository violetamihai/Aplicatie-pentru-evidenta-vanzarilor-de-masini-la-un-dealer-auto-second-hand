using Firma_vanzari_auto.Pages.Clienti;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System;
using System.Data.SqlClient;
namespace Firma_vanzari_auto.Pages.Colegii_mei
{
    public class IndexModel : PageModel
    {
		public List<ColegInfo> listColeg = new List<ColegInfo>();
        public List<ColegNouInfo> listColegNou = new List<ColegNouInfo>();
		public String InformatieColegNou = "Haideti sa ii primim pe noii nostri colegi: ";
        public void OnGet()
        {
			try
			{
				String connectionString = "Data Source=DESKTOP-MI4FVE6\\SQLEXPRESS;Initial Catalog=ProiectMihaiVioleta;Integrated Security=True;Encrypt=False";

				using (SqlConnection connection = new SqlConnection(connectionString))
				{
					connection.Open();
					String sql = "select Dealer.Nume, Dealer.Prenume, Reprezentanta.Oras , Reprezentanta.Strada,Dealer.Email, Dealer.Telefon from dealer,reprezentanta where Dealer.ReprezentantaID=Reprezentanta.ReprezentantaID group by Reprezentanta.Oras,Dealer.Nume, Dealer.Prenume,Reprezentanta.Strada,Dealer.Email, Dealer.Telefon";
					using (SqlCommand command = new SqlCommand(sql, connection))
					{
						using (SqlDataReader reader = command.ExecuteReader())
						{
							while (reader.Read())
							{
								ColegInfo colegInfo = new ColegInfo();
								
								colegInfo.Nume = reader.GetString(0);
								colegInfo.Prenume = reader.GetString(1);
								
								colegInfo.Oras = reader.GetString(2);
								colegInfo.Strada = reader.GetString(3);
						
								colegInfo.Email = reader.GetString(4);
								colegInfo.Telefon = reader.GetString(5);
								

								listColeg.Add(colegInfo);
							}

						}
					}
				}
			}
			catch (Exception ex)
			{
				
			}


            try
            {
                String connectionString = "Data Source=DESKTOP-MI4FVE6\\SQLEXPRESS;Initial Catalog=ProiectMihaiVioleta;Integrated Security=True;Encrypt=False";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    String sql = "SELECT  nume, prenume, Reprezentanta.Oras FROM Dealer, Reprezentanta WHERE (dataangajarii) IN (SELECT max(d2.dataangajarii) FROM Dealer d2 WHERE d2. ReprezentantaID=Dealer.ReprezentantaID GROUP BY ReprezentantaID) and Dealer.ReprezentantaID=Reprezentanta.ReprezentantaID ORDER BY dataangajarii";
                    using (SqlCommand command = new SqlCommand(sql, connection))
                    {
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                ColegNouInfo colegNouInfo = new ColegNouInfo();

                                colegNouInfo.Nume = reader.GetString(0);
                                colegNouInfo.Prenume = reader.GetString(1);

                                colegNouInfo.Oras = reader.GetString(2);

								InformatieColegNou = InformatieColegNou+ colegNouInfo.Nume + " "+colegNouInfo.Prenume + " "+"din" + " "  +colegNouInfo.Oras +";";



								listColegNou.Add(colegNouInfo);
                            }

                        }
                    }
                }
            }
            catch (Exception ex)
            {

            }

        }
	}






	public class ColegInfo
	{
	
		public String Nume;
		public String Prenume;
		public String Oras;
		public String Strada;
		public String Telefon;
		public String Email;
		

	}

    public class ColegNouInfo
    {

        public String Nume;
        public String Prenume;
        public String Oras;
      


    }


}

