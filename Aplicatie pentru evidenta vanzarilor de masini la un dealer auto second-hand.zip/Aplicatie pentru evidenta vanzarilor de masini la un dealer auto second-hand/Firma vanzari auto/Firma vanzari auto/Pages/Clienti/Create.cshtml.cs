using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Data.SqlClient;

namespace Firma_vanzari_auto.Pages.Clienti
{
    public class CreateModel : PageModel
    {
        public ClientInfo clientInfo = new ClientInfo();
		public String errorMessage = "";
		public String successMessage = "";

		public bool IsDigitsOnly(string str)
		{
			foreach (char c in str)
			{
				if (c < '0' || c > '9')
					return false;
			}

			return true;
		}

		public void OnGet()
        {
        }
        public void OnPost()
        {
            clientInfo.Nume = Request.Form["Nume"];
			clientInfo.Prenume = Request.Form["Prenume"];
			clientInfo.CNP = Request.Form["CNP"];
			clientInfo.Oras = Request.Form["Oras"];
			clientInfo.Strada = Request.Form["Strada"];
			clientInfo.Numar = Request.Form["Numar"];
			clientInfo.Bloc = Request.Form["Bloc"];
			clientInfo.Apartament = Request.Form["Apartament"];
			clientInfo.Telefon = Request.Form["Telefon"];
			clientInfo.Email = Request.Form["Email"];
			clientInfo.NrComenzi = Request.Form["NrComenzi"];
			clientInfo.SerieBuletin = Request.Form["SerieBuletin"];
			clientInfo.NrBuletin = Request.Form["NrBuletin"];

			//mesaje de eroare

			if (clientInfo.Nume.Length ==0 || clientInfo.Prenume.Length == 0 || clientInfo.Oras.Length == 0 || clientInfo.Strada.Length == 0
				|| clientInfo.Numar.Length == 0 || clientInfo.Telefon.Length == 0 || clientInfo.Email.Length == 0)
			{
				errorMessage = "Completati campurile obligatorii.";
				return;
			}

			if (clientInfo.CNP.Length != 13)
			{
				errorMessage = "CNP-ul introdus nu este corect.";
				return;
			}

			if (IsDigitsOnly(clientInfo.NrComenzi) == false)
			{
				errorMessage = "Numarul de comenzi trebuie sa fie un numar.";
				return;
			}

			if (IsDigitsOnly(clientInfo.Telefon) == false)
			{
				errorMessage = "Numarul de telefon trebuie sa fie un numar.";
				return;
			}

			//save to database

			try
			{
				String connectionString = "Data Source=DESKTOP-MI4FVE6\\SQLEXPRESS;Initial Catalog=ProiectMihaiVioleta;Integrated Security=True;Encrypt=False";
				using (SqlConnection connection = new SqlConnection(connectionString)) {
					connection.Open();
					String sql = "INSERT INTO Client " + "(Nume, Prenume, CNP, Oras, Strada, Numar, Bloc, Apartament, Telefon, Email, NrComenzi, SerieBuletin, NrBuletin) VALUES" +
						"(@Nume, @Prenume, @CNP, @Oras, @Strada, @Numar, @Bloc, @Apartament, @Telefon, @Email, @NrComenzi, @SerieBuletin, @NrBuletin);";
				
				using (SqlCommand command = new SqlCommand(sql, connection)) {
						command.Parameters.AddWithValue("@Nume", clientInfo.Nume);
						command.Parameters.AddWithValue("@Prenume", clientInfo.Prenume);
						command.Parameters.AddWithValue("@CNP", clientInfo.CNP);
						command.Parameters.AddWithValue("@Oras", clientInfo.Oras);
						command.Parameters.AddWithValue("@Strada", clientInfo.Strada);
						command.Parameters.AddWithValue("@Numar", clientInfo.Numar);
						command.Parameters.AddWithValue("@Bloc", clientInfo.Bloc);
						command.Parameters.AddWithValue("@Apartament", clientInfo.Apartament);
						command.Parameters.AddWithValue("@Telefon", clientInfo.Telefon);
						command.Parameters.AddWithValue("@Email", clientInfo.Email);
						command.Parameters.AddWithValue("@NrComenzi", clientInfo.NrComenzi);
						command.Parameters.AddWithValue("@SerieBuletin", clientInfo.SerieBuletin);
						command.Parameters.AddWithValue("@NrBuletin", clientInfo.NrBuletin);
						
						command.ExecuteNonQuery();

					}
				}
			}
			catch(Exception ex)
			{
				errorMessage = ex.Message;
				return;
			}


			//eliberam campurile pentru urmatorul add
			clientInfo.Nume = "";
			clientInfo.Prenume = "";
			clientInfo.CNP = "";
			clientInfo.Oras = "";
			clientInfo.Strada = "";
			clientInfo.Numar = "";
			clientInfo.Bloc = "";
			clientInfo.Apartament = "";
			clientInfo.Telefon = "";
			clientInfo.Email = "";
			clientInfo.NrComenzi = "";
			clientInfo.SerieBuletin = "";
			clientInfo.NrBuletin = "";

			//mesaj succes
			successMessage = "Client adaugat cu succes";

			//dupa add, redirect pe show clienti
			Response.Redirect("/Clienti/Index");

		}
    }
}
