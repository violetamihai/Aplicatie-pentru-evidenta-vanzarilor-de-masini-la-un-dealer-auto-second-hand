using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System;
using System.Data.SqlClient;

namespace Firma_vanzari_auto.Pages.Clienti
{
    public class IndexModel : PageModel
    {
        public List<ClientInfo> listClients = new List<ClientInfo>();
        public void OnGet()
        {
            try
            {
                String connectionString = "Data Source=DESKTOP-MI4FVE6\\SQLEXPRESS;Initial Catalog=ProiectMihaiVioleta;Integrated Security=True;Encrypt=False";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    String sql = "SELECT * FROM Client";
                    using (SqlCommand command = new SqlCommand(sql, connection))
                    {
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read()) 
                            {
                                ClientInfo clientInfo = new ClientInfo();
                                clientInfo.ClientID = "" + reader.GetInt32(0);
                                clientInfo.Nume = reader.GetString(1);
                                clientInfo.Prenume = reader.GetString(2);
                                clientInfo.CNP = reader.GetString(3);
                                clientInfo.Oras = reader.GetString(4);
                                clientInfo.Strada = reader.GetString(5);
                                clientInfo.Numar = reader.GetString(6);
                                clientInfo.Bloc = reader.GetString(7);
                                clientInfo.Apartament = reader.GetString(8);
                                clientInfo.Telefon = reader.GetString(9);
                                clientInfo.Email = reader.GetString(10);
                                clientInfo.NrComenzi = "" + reader.GetInt32(11);
                                clientInfo.SerieBuletin = reader.GetString(12);
                                clientInfo.NrBuletin = reader.GetString(13);
                                /*clientInfo.created_at = reader.GetDateTime(5).ToString();*/

                                listClients.Add(clientInfo);
                            }

                        }
                    }
                }
            }
            catch (Exception)
            {/*
               Console.WriteLine("Exception: " + ex.ToString());
*/
                throw;
            }

        }
    }

    public class ClientInfo
    {
        public String ClientID;
        public String Nume;
        public String Prenume;
        public String CNP;
        public String Oras;
        public String Strada;
        public String Numar;
        public String Bloc;
        public String Apartament;
        public String Telefon;
        public String Email;
        public String NrComenzi;
        public String SerieBuletin;
        public String NrBuletin;
        public String created_at;

    }

	
}
