using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System;
using System.Data.SqlClient;

namespace Firma_vanzari_auto.Pages.Clienti
{
    public class Client_EditModel : PageModel
	{
		public ClientInfo clientInfo = new ClientInfo();
		public String errorMessage = "";
		public String successMessage = "";

		public bool IsDigitsOnly(string str)
		{
			foreach (char c in str)
			{
				if (c < '0' || c > '9')
					return false;
			}

			return true;
		}
		public void OnGet()
        {
			 String id = Request.Query["id"];

			try
			{
				String connectionString = "Data Source=DESKTOP-MI4FVE6\\SQLEXPRESS;Initial Catalog=ProiectMihaiVioleta;Integrated Security=True;Encrypt=False";
				using (SqlConnection connection = new SqlConnection(connectionString))
				{
					connection.Open();
					String sql = "SELECT * FROM Client WHERE ClientID=@id";

					using (SqlCommand command = new SqlCommand(sql, connection))
					{
						command.Parameters.AddWithValue("@id", id);
						using (SqlDataReader reader = command.ExecuteReader())
						{
							if (reader.Read())
							{
								clientInfo.ClientID = "" + reader.GetInt32(0);
								clientInfo.Nume = reader.GetString(1);
								clientInfo.Prenume = reader.GetString(2);
								clientInfo.CNP = reader.GetString(3);
								clientInfo.Oras = reader.GetString(4);
								clientInfo.Strada = reader.GetString(5);
								clientInfo.Numar = reader.GetString(6);
								clientInfo.Bloc = reader.GetString(7);
								clientInfo.Apartament = reader.GetString(8);
								clientInfo.Telefon = reader.GetString(9);
								clientInfo.Email = reader.GetString(10);
								clientInfo.NrComenzi = "" + reader.GetInt32(11);
								clientInfo.SerieBuletin = reader.GetString(12);
								clientInfo.NrBuletin = reader.GetString(13);

							}
						}

					}
				}
			}
			catch(Exception ex)
			{
				errorMessage = ex.Message + "primul";
			}
        }

		public void OnPost() 
		{
			clientInfo.ClientID = Request.Query["id"];
			clientInfo.Nume = Request.Form["Nume"];
			clientInfo.Prenume = Request.Form["Prenume"];
			clientInfo.CNP = Request.Form["CNP"];
			clientInfo.Oras = Request.Form["Oras"];
			clientInfo.Strada = Request.Form["Strada"];
			clientInfo.Numar = Request.Form["Numar"];
			clientInfo.Bloc = Request.Form["Bloc"];
			clientInfo.Apartament = Request.Form["Apartament"];
			clientInfo.Telefon = Request.Form["Telefon"];
			clientInfo.Email = Request.Form["Email"];
			clientInfo.NrComenzi = Request.Form["NrComenzi"];
			clientInfo.SerieBuletin = Request.Form["SerieBuletin"];
			clientInfo.NrBuletin = Request.Form["NrBuletin"];

			if (clientInfo.Nume.Length == 0 || clientInfo.Prenume.Length == 0 || clientInfo.Oras.Length == 0 || clientInfo.Strada.Length == 0
				|| clientInfo.Numar.Length == 0 || clientInfo.Telefon.Length == 0 || clientInfo.Email.Length == 0)
			{
				errorMessage = "Completati campurile obligatorii.";
				return;
			}

			if (clientInfo.CNP.Length != 13)
			{
				errorMessage = "CNP-ul introdus nu este corect.";
				return;
			}

			if (IsDigitsOnly(clientInfo.NrComenzi) == false)
			{
				errorMessage = "Numarul de comenzi trebuie sa fie un numar.";
				return;
			}

			if (IsDigitsOnly(clientInfo.Telefon) == false)
			{
				errorMessage = "Numarul de telefon trebuie sa fie un numar.";
				return;
			}

			try
			{
				String connectionString = "Data Source=DESKTOP-MI4FVE6\\SQLEXPRESS;Initial Catalog=ProiectMihaiVioleta;Integrated Security=True;Encrypt=False";
				using (SqlConnection connection = new SqlConnection(connectionString))
				{
					connection.Open();
					String sql = "UPDATE Client " +
						"SET Nume=@Nume, Prenume=@Prenume, CNP=@CNP, Oras=@Oras, Strada=@Strada, Numar=@Numar, Bloc=@Bloc, Apartament=@Apartament, Telefon=@Telefon, Email=@Email, NrComenzi=@NrComenzi, SerieBuletin=@SerieBuletin, NrBuletin=@NrBuletin " +
						"WHERE ClientID = @id";

					using (SqlCommand command = new SqlCommand(sql, connection))
					{
						
						command.Parameters.AddWithValue("@Nume", clientInfo.Nume);
						command.Parameters.AddWithValue("@Prenume", clientInfo.Prenume);
						command.Parameters.AddWithValue("@CNP", clientInfo.CNP);
						command.Parameters.AddWithValue("@Oras", clientInfo.Oras);
						command.Parameters.AddWithValue("@Strada", clientInfo.Strada);
						command.Parameters.AddWithValue("@Numar", clientInfo.Numar);
						command.Parameters.AddWithValue("@Bloc", clientInfo.Bloc);
						command.Parameters.AddWithValue("@Apartament", clientInfo.Apartament);
						command.Parameters.AddWithValue("@Telefon", clientInfo.Telefon);
						command.Parameters.AddWithValue("@Email", clientInfo.Email);
						command.Parameters.AddWithValue("@NrComenzi", clientInfo.NrComenzi);
						command.Parameters.AddWithValue("@SerieBuletin", clientInfo.SerieBuletin);
						command.Parameters.AddWithValue("@NrBuletin", clientInfo.NrBuletin);
						command.Parameters.AddWithValue("@id", clientInfo.ClientID);

						command.ExecuteNonQuery();

					}
				}

			}

			catch(Exception ex)
			{
				errorMessage = ex.Message+ "al dpilea";
				return;
			}

			//mesaj succes
			successMessage = "Client modificat cu succes";

			//dupa add, redirect pe show clienti
			Response.Redirect("/Clienti/Index");


		}
    }
}
