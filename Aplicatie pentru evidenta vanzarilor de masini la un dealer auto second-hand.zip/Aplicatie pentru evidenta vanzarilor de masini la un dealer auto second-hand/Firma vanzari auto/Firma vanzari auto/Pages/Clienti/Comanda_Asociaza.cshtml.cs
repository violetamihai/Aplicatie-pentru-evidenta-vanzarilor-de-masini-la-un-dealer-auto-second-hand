using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System;
using System.Data.SqlClient;
using System.Security.Cryptography.X509Certificates;

namespace Firma_vanzari_auto.Pages.Clienti
{
    public class Comanda_AsociazaModel : PageModel
    {
		public ComandaInfo comandaInfo = new ComandaInfo();
		public String errorMessage = "";
		public String successMessage = "";
		public int DealerID;
		public String NumeDealer = "";
		public void OnGet()
        {
        }
		public void OnPost()
		{
			String id = Request.Query["id"];
			comandaInfo.ComandaID = Request.Query["id"];
			NumeDealer = Request.Form["NumeDealer"];

			try
			{
				if (NumeDealer == "Popescu Marian")
					DealerID = 2;
				else if (NumeDealer == "Popa Mihai")
					DealerID = 4;
				else if (NumeDealer == "Mihailescu Dan")
					DealerID = 5;
				else if (NumeDealer == "Toma Maria")
					DealerID = 6;
				else if (NumeDealer == "Vlaicu Marin")
					DealerID = 7;
				else if (NumeDealer == "Gostan Horia")
					DealerID = 8;
				else if (NumeDealer == "Dovleac Mihnea")
					DealerID = 9;
				else if (NumeDealer == "Andrei Elisabeta")
					DealerID = 10;
				else if (NumeDealer == "Pop Bianca")
					DealerID = 13;


				String connectionString = "Data Source=DESKTOP-MI4FVE6\\SQLEXPRESS;Initial Catalog=ProiectMihaiVioleta;Integrated Security=True;Encrypt=False";
				using (SqlConnection connection = new SqlConnection(connectionString))
				{
					connection.Open();
					String sql = "INSERT INTO ComandaDealer " + "(DealerID,ComandaID) VALUES" +
						"(@DealerID,@id);";

					using (SqlCommand command = new SqlCommand(sql, connection))
					{
						command.Parameters.AddWithValue("@id", id);
						command.Parameters.AddWithValue("@DealerID", DealerID);


						command.ExecuteNonQuery();

					}
				}

			}

			catch (Exception ex)
			{
				errorMessage = ex.Message;
				return;
			}

			Response.Redirect("/Clienti/Index");
		}
	}
}


