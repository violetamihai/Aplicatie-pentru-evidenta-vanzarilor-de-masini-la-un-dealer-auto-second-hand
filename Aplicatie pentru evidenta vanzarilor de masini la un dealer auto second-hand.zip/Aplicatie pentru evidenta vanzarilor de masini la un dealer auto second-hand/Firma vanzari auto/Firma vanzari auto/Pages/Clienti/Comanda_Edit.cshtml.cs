using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System;
using System.Data.SqlClient;
using System.Security.Cryptography.X509Certificates;

namespace Firma_vanzari_auto.Pages.Clienti
{
    public class Comanda_EditModel : PageModel
    {
		public ComandaInfo comandaInfo = new ComandaInfo();
		public String errorMessage = "";
		public String successMessage = "";

		public bool IsDigitsOnly(string str)
		{
			foreach (char c in str)
			{
				if (c < '0' || c > '9')
					return false;
			}

			return true;
		}
		public void OnGet()
		{
			String id = Request.Query["id"];
			String id_comanda= Request.Query["id_comanda"];
			try
			{
				String connectionString = "Data Source=DESKTOP-MI4FVE6\\SQLEXPRESS;Initial Catalog=ProiectMihaiVioleta;Integrated Security=True;Encrypt=False";
				using (SqlConnection connection = new SqlConnection(connectionString))
				{
					connection.Open();
					String sql = "SELECT Valoare,ModalitatePlata, NrMasini,Data FROM Comanda WHERE Comanda.ComandaID=@id_comanda";

					using (SqlCommand command = new SqlCommand(sql, connection))
					{
						//command.Parameters.AddWithValue("@id", id);
						command.Parameters.AddWithValue("@id_comanda", id);
						using (SqlDataReader reader = command.ExecuteReader())
						{
							if (reader.Read())
							{
								comandaInfo.ComandaID =""+ id;
								comandaInfo.Valoare = "" + reader.GetInt32(0);
								comandaInfo.ModalitatePlata = reader.GetString(1);
								comandaInfo.NrMasini = "" + reader.GetInt32(2); ;
								comandaInfo.Data = reader.GetDateTime(3);

							}
						}
					}
				}
			}
			catch (Exception ex)
			{
				errorMessage = ex.Message+"priul" ;
			}
		}

		public void OnPost()
		{
			String id = Request.Query["id"];
			comandaInfo.ComandaID = Request.Query["id"];
			comandaInfo.Valoare = Request.Form["Valoare"];
			comandaInfo.ModalitatePlata = Request.Form["ModalitatePlata"];
			comandaInfo.NrMasini = Request.Form["NrMasini"];
			comandaInfo.Data = DateTime.Now;

			// campuri
			if (comandaInfo.Valoare.Length == 0 || comandaInfo.ModalitatePlata.Length == 0 || comandaInfo.NrMasini.Length == 0)
			{
				errorMessage = "Completati campurile obligatorii.";
				return;
			}

			if(IsDigitsOnly(comandaInfo.Valoare) == false)
			{
				errorMessage = "Valoarea trebuie sa fie un numar.";
				return;
			}

			if (IsDigitsOnly(comandaInfo.NrMasini) == false)
			{
				errorMessage = "Numarul de masini trebuie sa fie un numar.";
				return;
			}
			if (comandaInfo.ModalitatePlata != "Online" && comandaInfo.ModalitatePlata != "Card" && comandaInfo.ModalitatePlata != "Cash" && comandaInfo.ModalitatePlata != "Leasing")
			{
				errorMessage = "Modalitatile permise de plata sunt: Online, Card, Cash, Leasing.";
				return;
			}


			try
			{
				String connectionString = "Data Source=DESKTOP-MI4FVE6\\SQLEXPRESS;Initial Catalog=ProiectMihaiVioleta;Integrated Security=True;Encrypt=False";
				using (SqlConnection connection = new SqlConnection(connectionString))
				{
					connection.Open();
					String sql = "UPDATE Comanda " +
						"SET Valoare=@Valoare, ModalitatePlata=@ModalitatePlata, NrMasini=@NrMasini,Data=@Data " +
						"WHERE ComandaID = @id ";

					using (SqlCommand command = new SqlCommand(sql, connection))
					{

						command.Parameters.AddWithValue("@Valoare", comandaInfo.Valoare);
						command.Parameters.AddWithValue("@ModalitatePlata", comandaInfo.ModalitatePlata);
						command.Parameters.AddWithValue("@NrMasini", comandaInfo.NrMasini);
						command.Parameters.AddWithValue("@Data", comandaInfo.Data);
						command.Parameters.AddWithValue("@id", id);

						command.ExecuteNonQuery();

					}
				}

			}

			catch (Exception ex)
			{
				errorMessage = ex.Message +"al doilea";
				return;
			}

			//mesaj succes
			successMessage = "Comanda modificat cu succes";

			//dupa add, redirect pe show clienti
			Response.Redirect("/Clienti/Index");


		}
	}
}



