using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System;
using System.Data.SqlClient;

namespace Firma_vanzari_auto.Pages.Clienti
{
    public class Comanda_NouaModel : PageModel
    {

		public List<ComandaInfo> listComenzi = new List<ComandaInfo>();
		public ComandaInfo comandaInfo = new ComandaInfo();
		public String errorMessage = "";
		public String successMessage = "";
		public bool IsDigitsOnly(string str)
		{
			foreach (char c in str)
			{
				if (c < '0' || c > '9')
					return false;
			}

			return true;
		}

		public void OnGet()
		{
			String id = Request.Query["id"];
			try
			{
				String connectionString = "Data Source=DESKTOP-MI4FVE6\\SQLEXPRESS;Initial Catalog=ProiectMihaiVioleta;Integrated Security=True;Encrypt=False";

				using (SqlConnection connection = new SqlConnection(connectionString))
				{
					connection.Open();
					String sql = "SELECT Comanda.ComandaID, Valoare, ModalitatePlata,NrMasini, Data, Client.ClientID  FROM Comanda, Client WHERE Comanda.ClientID = @id AND Client.ClientID=@id";
					using (SqlCommand command = new SqlCommand(sql, connection))
					{
						command.Parameters.AddWithValue("@id", id);
						using (SqlDataReader reader = command.ExecuteReader())
						{
							while (reader.Read())
							{
								ComandaInfo comandaInfo = new ComandaInfo();
								comandaInfo.ComandaID = "" + reader.GetInt32(0);
								comandaInfo.Valoare = "" + reader.GetInt32(1);
								comandaInfo.ModalitatePlata = reader.GetString(2);
								comandaInfo.NrMasini = "" + reader.GetInt32(3);
								comandaInfo.Data = reader.GetDateTime(4);
								comandaInfo.ClientID = "" + reader.GetInt32(5);
								listComenzi.Add(comandaInfo);

								
							}

						}
					}
				}
			}
			catch (Exception ex)
			{
				errorMessage = ex.Message + "al doilea";
				return;
			}

		}
	}
}




	public class ComandaInfo
	{
	public String ClientID;
	public String ComandaID;
	public String Valoare;
	public String ModalitatePlata;
	public String NrMasini;
	public String Data;
		

	}



