using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System;
using System.Data.SqlClient;
using System.Numerics;

namespace Firma_vanzari_auto.Pages.Clienti
{
	public class Client_DetaliiModel : PageModel
	{
		public ClientInfo clientInfo = new ClientInfo();
		public ComandaInfo comandaInfo = new ComandaInfo();
		public String errorMessage = "";
		public String successMessage = "";
		public String InformatieComenzi = "" + "<br>";
		


		public void OnGet()
		{
			String id = Request.Query["id"];
			int nr = 0;

			try
			{
				String connectionString = "Data Source=DESKTOP-MI4FVE6\\SQLEXPRESS;Initial Catalog=ProiectMihaiVioleta;Integrated Security=True;Encrypt=False";
				using (SqlConnection connection = new SqlConnection(connectionString))
				{
					connection.Open();
					String sql = "SELECT * FROM Client WHERE ClientID=@id";

					using (SqlCommand command = new SqlCommand(sql, connection))
					{
						command.Parameters.AddWithValue("@id", id);
						using (SqlDataReader reader = command.ExecuteReader())
						{
							if (reader.Read())
							{
								clientInfo.ClientID = "" + reader.GetInt32(0);
								clientInfo.Nume = reader.GetString(1);
								clientInfo.Prenume = reader.GetString(2);
								clientInfo.CNP = reader.GetString(3);
								clientInfo.Oras = reader.GetString(4);
								clientInfo.Strada = reader.GetString(5);
								clientInfo.Numar = reader.GetString(6);
								clientInfo.Bloc = reader.GetString(7);
								clientInfo.Apartament = reader.GetString(8);
								clientInfo.Telefon = reader.GetString(9);
								clientInfo.Email = reader.GetString(10);
								clientInfo.NrComenzi = "" + reader.GetInt32(11);
								clientInfo.SerieBuletin = reader.GetString(12);
								clientInfo.NrBuletin = reader.GetString(13);

							}
						}

					}
				}
			}
			catch (Exception ex)
			{
				errorMessage = ex.Message + "primul";
			}


			try
			{
				String connectionString = "Data Source=DESKTOP-MI4FVE6\\SQLEXPRESS;Initial Catalog=ProiectMihaiVioleta;Integrated Security=True;Encrypt=False";
				using (SqlConnection connection = new SqlConnection(connectionString))
				{
					connection.Open();
					String sql = "SELECT Client.Nume,Client.Prenume, Comanda.Valoare, Comanda.ModalitatePlata, Comanda.NrMasini, Comanda.Data, Comanda.ComandaID FROM Comanda, Client WHERE Comanda.ClientID = @id AND Client.ClientID=@id";

					using (SqlCommand command = new SqlCommand(sql, connection))
					{
						command.Parameters.AddWithValue("@id", id);
						using (SqlDataReader reader = command.ExecuteReader())
						{
							nr = 0;
							while (reader.Read())
							{
								nr++;
								
								comandaInfo.Nume = reader.GetString(0);
								comandaInfo.Prenume = reader.GetString(1);
								comandaInfo.Valoare = "" + reader.GetInt32(2);
								comandaInfo.ModalitatePlata = reader.GetString(3);
								comandaInfo.NrMasini = "" + reader.GetInt32(4);
								comandaInfo.Data = reader.GetDateTime(5);
								//comandaInfo.ComandaID = comandaInfo.Valoare = "" + reader.GetInt32(6);

								InformatieComenzi = InformatieComenzi+ "Comanda "+ nr  +"<br>" + "Valoare comanda: " + comandaInfo.Valoare + "<br>" + "Modalitate de Plata: " + comandaInfo.ModalitatePlata
									+ "<br>" + "Numarul de masini: " + comandaInfo.NrMasini+ "<br>" + "Data: " +comandaInfo.Data+ "<br>"+ "<br>";


								InformatieComenzi = InformatieComenzi.Replace("@", System.Environment.NewLine);

							}
						}

					}
				}
			}
			catch (Exception ex)
			{
				errorMessage = ex.Message + "detalii";
			}
		}
	}

	public class ComandaInfo
	{
		
		public String Nume;
		public String Prenume;
		public String ClientID;
		public String ComandaID;
		public String Valoare;
		public String ModalitatePlata;
		public String NrMasini;
		public DateTime Data;


	}
}


